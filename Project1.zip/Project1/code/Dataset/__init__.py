import random
import sys
import os

# Append the current working directory to sys.path
sys.path.append(os.getcwd())